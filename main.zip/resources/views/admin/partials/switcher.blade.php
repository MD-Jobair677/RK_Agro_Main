<span class="switch-toggle-slider">
    <span class="switch-on">
        <i class="las la-check align-middle"></i>
    </span>
    <span class="switch-off">
        <i class="las la-times align-middle"></i>
    </span>
</span>
<span class="switch-label"></span>
